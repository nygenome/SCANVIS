## ------------------------------------------------------------------------
gen19<-get(load(url("https://github.com/nygenome/SCANVIS/blob/master/gen19.scanvis.Rdata?raw=true")))

## ------------------------------------------------------------------------
library(SCANVIS)
data(SCANVIS_examples)
head(gbm3)
gbm3.scn<-SCANVIS.scan(sj=gbm3,gen=gen19,Rcut=5,bam=NULL,samtools=NULL)
head(gbm3.scn)

## ------------------------------------------------------------------------
head(gbm3.vcf)
gbm3.scnv<-SCANVIS.linkvar(gbm3.scn,gbm3.vcf,gen19)
head(gbm3.scnv)

## ------------------------------------------------------------------------
tail(gbm3.scnv)

## ------------------------------------------------------------------------
gbm3.scnvp<-SCANVIS.linkvar(gbm3.scn,gbm3.vcf,gen19,p=100)
table(gbm3.scnv[,'passedMUT'])
table(gbm3.scnvp[,'passedMUT'])

## ------------------------------------------------------------------------
par(mfrow=c(2,1),mar=c(1,1,1,1))
vis.lusc1<-SCANVIS.visual('PPA2',gen19,LUSC[[1]],TITLE=names(LUSC)[1],full.annot=TRUE,bam=NULL,samtools=NULL)
vis.lusc2<-SCANVIS.visual('PPA2',gen19,LUSC[[2]],TITLE=names(LUSC)[2],full.annot=TRUE,bam=NULL,samtools=NULL,USJ='RRS')

## ------------------------------------------------------------------------
ASJ<-tail(vis.lusc2$sj)[,1:3]
c2<-SCANVIS.visual('PPA2',gen19,LUSC[[2]],TITLE=names(LUSC)[2],full.annot=TRUE,SJ.special=ASJ)

## ------------------------------------------------------------------------
vis.lusc.merged<-SCANVIS.visual('PPA2',gen19,LUSC,TITLE='Two LUSC samples, merged',full.annot=TRUE)

