### R code from vignette source 'runningSCANVIS.Rnw'

###################################################
### code chunk number 1: runningSCANVIS.Rnw:31-32
###################################################
gen19<-get(load(url("https://github.com/nygenome/SCANVIS/blob/master/gen19.scanvis.Rdata?raw=true")))


###################################################
### code chunk number 2: runningSCANVIS.Rnw:43-48
###################################################
library(SCANVIS)
data(SCANVIS_examples)
head(gbm3)
gbm3.scn<-SCANVIS.scan(sj=gbm3,gen=gen19,Rcut=5,bam=NULL,samtools=NULL)
head(gbm3.scn)


###################################################
### code chunk number 3: runningSCANVIS.Rnw:58-61
###################################################
head(gbm3.vcf)
gbm3.scnv<-SCANVIS.linkvar(gbm3.scn,gbm3.vcf,gen19)
head(gbm3.scnv)


###################################################
### code chunk number 4: runningSCANVIS.Rnw:65-66
###################################################
tail(gbm3.scnv)


###################################################
### code chunk number 5: runningSCANVIS.Rnw:71-74
###################################################
gbm3.scnvp<-SCANVIS.linkvar(gbm3.scn,gbm3.vcf,gen19,p=100)
table(gbm3.scnv[,'passedMUT'])
table(gbm3.scnvp[,'passedMUT'])


###################################################
### code chunk number 6: runningSCANVIS.Rnw:85-88
###################################################
par(mfrow=c(2,1),mar=c(1,1,1,1))
vis.lusc1<-SCANVIS.visual('PPA2',gen19,LUSC[[1]],TITLE=names(LUSC)[1],full.annot=TRUE,bam=NULL,samtools=NULL)
vis.lusc2<-SCANVIS.visual('PPA2',gen19,LUSC[[2]],TITLE=names(LUSC)[2],full.annot=TRUE,bam=NULL,samtools=NULL,USJ='RRS')


###################################################
### code chunk number 7: runningSCANVIS.Rnw:93-95
###################################################
ASJ<-tail(vis.lusc2$sj)[,1:3]
c2<-SCANVIS.visual('PPA2',gen19,LUSC[[2]],TITLE=names(LUSC)[2],full.annot=TRUE,SJ.special=ASJ)


###################################################
### code chunk number 8: runningSCANVIS.Rnw:100-101
###################################################
vis.lusc.merged<-SCANVIS.visual('PPA2',gen19,LUSC,TITLE='Two LUSC samples, merged',full.annot=TRUE)


