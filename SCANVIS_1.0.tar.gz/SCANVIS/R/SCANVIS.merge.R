#INPUT: scn=urls to scn files output by SCANVIS.scan/linkvar
#			OR scn can also be a list of matrices
#		method='mean' or 'median'
#		roi=region of interest chr,start,end
#		gen=gencode data
#
#OUTPUT: object with components sj, sj.samples and muts (muts available only if scn are outputs of SCANVIS.linkvar)
#			out$sj=averaged PSI and uniq.reads across samples
#		    out$sj.samples=comma separated samples, PSIs and uniq.reads for each sj in out$sj
#			out$muts=all mutations mapped to sjs in out$sj, with comma separated samples and number of samples containing the mutation
SCANVIS.merge<-function(scn,method='mean',roi=NULL,gen=NULL){

	roi.g=NULL
	if(length(roi)>0){
		if(length(grep('chr',roi))==0){
			if(length(gen)==0) stop('Please supply gencode details so that the appropriate genomic region for your query genes can be derived')
			roi.g=roi
			roi=gene2roi(roi,gen)
		}
	}
	if(length(roi)==0 & length(scn)>50)
		stop('For more than 50 samples, we recommend merging or agglomerating samples for a query region or chr, otherwise resulting data matrices will be too large')

	PSI=matrix(0,2,2)
	rownames(PSI)=c('nada1','nada2')
	colnames(PSI)=rownames(PSI)
	NR=PSI
	MUTS=PSI

	for(i in 1:length(scn)){
		if(class(scn)=='list'){
			id=names(scn)[i]
			sj=scn[[i]]
		}
		if(class(scn)=='character'){
			id=sj[i]
			sj=as.matrix(read.delim(scn[i]))
		}
		if(length(roi)>0) sj=sj[which(sj[,'chr']==roi[1]),]
		if(length(roi)>1){
			q=which(as.numeric(sj[,'start'])>=as.numeric(roi[2]))
			q=q[which(as.numeric(sj[q,'end'])<=as.numeric(roi[3]))]
			sj=sj[q,]
		}
		sj=gsub(' ','',sj)
		rownames(sj)=paste(sj[,'chr'],sj[,'start'],sj[,'end'],sj[,'JuncType'],sj[,'gene_name'],sj[,'FrameStatus'])

		PSI=add2mat(PSI,sj,id,'PSI')
		NR=add2mat(NR,sj,id,'uniq.reads')

		q=max(which(is.element(colnames(sj),c('FrameStatus','covPSI'))))
		if(ncol(sj)>q){
			Q=(q+1):ncol(sj)
			MUTS=addmut(MUTS,sj[,Q],id)
		}
	}

	PSI=PSI[3:nrow(PSI),3:ncol(PSI)]
	NR=NR[3:nrow(NR),3:ncol(NR)]
	if(nrow(MUTS)==2) MUTS=NULL
	if(length(MUTS)>0){
		if(nrow(MUTS)>3)
			MUTS=MUTS[3:nrow(MUTS),3:ncol(MUTS)]
		if(nrow(MUTS)==3){
			tmp=rownames(MUTS)[3]
			MUTS=t(as.matrix(MUTS[3,3:ncol(MUTS)]))
			rownames(MUTS)=tmp
		}
	}

	#representative sample
	S0=t(matrix(unlist(strsplit(rownames(PSI),' ')),6,nrow(PSI)))
	if(method=='mean') S0=cbind(S0,apply(PSI,1,mean),apply(NR,1,mean))
	if(method=='median') S0=cbind(S0,apply(PSI,1,median),apply(NR,1,median))
	colnames(S0)=c('chr','start','end','JuncType','gene_name','FrameStatus','PSI','uniq.reads')

	out=NULL
	if(length(roi)>0) out$roi=roi
	if(length(roi.g)>0) out$roi=c(roi,paste(roi.g,collapse=','))
	out$PSI=PSI
	out$NR=NR
	if(length(MUTS)>0) out$MUTS=MUTS
	out$SJ=S0
	rownames(out$SJ)=NULL
	return(out)
}

add2mat<-function(mat,sj.new,id,whattoadd='PSI'){
	mat=cbind(mat,0)
	colnames(mat)[ncol(mat)]=id
	dd=setdiff(rownames(sj.new),rownames(mat))
	if(length(dd)>0){
		tmp=c(rownames(mat),dd)
		mat=rbind(mat,matrix(0,length(dd),ncol(mat)))
		rownames(mat)=tmp
	}
	xx=intersect(rownames(sj.new),rownames(mat))
	mat[xx,id]=as.numeric(sj.new[xx,whattoadd])
	return(mat)
}
addmut<-function(muts,mut.new,id){
	muts=cbind(muts,0)
	colnames(muts)[ncol(muts)]=id	
	mut.new=as.vector(mut.new)
	mut.new=mut.new[which(mut.new!='')]
	mut.new=mut.new[which(!is.na(mut.new))]
	mm=setdiff(unique(unlist(strsplit(mut.new,'\\|'))),'')
	if(length(mm)>0){
		dd=setdiff(mm,rownames(muts))
		if(length(dd)>0){
			tmp=c(rownames(muts),dd)
			muts=rbind(muts,matrix(0,length(dd),ncol(muts)))
			rownames(muts)=tmp
		}
		xx=intersect(mm,rownames(muts))
		muts[xx,id]=1
	}
	return(muts)
}

gene2roi<-function(g,gen){

	q=which(is.element(gen$GENES[,'gene_name'],g))
	tmp=intersect(g,gen$GENES[q,'gene_name'])
	if(length(tmp)==0) stop('Gene/s not found in the gencode object. Please check your gene list')
	if(length(tmp)!=length(g))
		print(paste('Gene/s',setdiff(g,tmp),'are not listed in the supplied gencode object and will be excluded.'))

	roi=NULL
	tt=sort(table(gen$GENES[q,'chr']))
	q=intersect(q,which(gen$GENES[,'chr']==tail(names(tt),1)))
	if(length(unique(gen$GENES[q,'chr']))!=1) stop('Gene list supplied occur in more than one chromosome. Please supply gene/s that occur in one chromosome only')
	roi=range(as.numeric(as.vector(gen$GENES[q,c('start','end')])))
	roi=c(tail(names(tt)[1]),roi)

	return(roi)
}

# #####################################################################################################################################

# 	N=length(scn)
# 	muts=NULL
# 	sj.samples=NULL
# 	sj=NULL

# 	roi0=roi
# 	if(length(roi)>0){
# 		if(length(roi)!=3 & length(roi)!=1) stop('roi must either be one gene name or a 3-bit vector with chr,start,end for region of interest')
# 		if(length(roi)!=3 | length(grep('chr',roi))==0) roi=gene2roi(roi,gen)
# 		chr=roi[1]
# 	}
# 	#initiating sj
# 	ii=1
# 	while(length(sj)==0){
# 		id=scn[ii]	
# 		print(paste('Merging ... sample 1 of',N))

# 		if(class(scn)=='list'){
# 			sj=gsub(' ','',scn[[1]])
# 			if(length(names(scn))==0) names(scn)=paste0('sample',1:N)
# 			id=names(scn)[1]
# 		}
# 		if(class(scn)=='character')
# 			sj=as.matrix(read.delim(scn[1]))

# 		q=1:nrow(sj)
# 		if(length(roi)>0){
# 			sj=sj[which(sj[,'chr']==chr),]
# 			q=unique(unlist(lapply(c('start','end'),function(x) intersect(which(as.numeric(sj[,x])>=as.numeric(roi[2])),which(as.numeric(sj[,x])<=as.numeric(roi[3]))))))
# 		}
# 		if(length(q)>0) sj=sj[q,]
# 		ii=ii+1
		
# 	}

# 	if(length(q)==1) sj=rbind(t(as.matrix(sj)),rep('nada',length(sj)))
# 	rownames(sj)=apply(gsub(' ','',sj[,c('chr','start','end')]),1,function(x) paste(x,collapse=' '))

# 	sj.samples=cbind(rep(id,nrow(sj)),sj[,'uniq.reads'],sj[,'PSI'])
# 	rownames(sj.samples)=rownames(sj)
# 	colnames(sj.samples)=c('sample.ids','uniq.reads','PSI')

# 	n=max(unlist(lapply(c('covPSI','FrameStatus'),function(x) grep(x,colnames(sj)))))
# 	if((ncol(sj)-n)>0){
# 		muts=setdiff(unique(unlist(strsplit(sj[,(n+1):ncol(sj)],'\\|'))),'')			
# 		if(length(muts)>1) muts=cbind(muts,rep(id,length(muts)),rep(1,length(muts)))
# 		if(length(muts)==1) muts=t(as.matrix(c(muts,id,1)))
# 	}

# 	for(i in 2:N){
# 		print(paste('Merging ... sample',i,'of',N))

# 		#print(paste('Uploading SCANVIS data for',scn[i]))
# 		if(class(scn)=='list'){
# 			tmp=gsub(' ','',scn[[i]])
# 			id=names(scn)[i]
# 		}
# 		if(class(scn)=='character'){
# 			tmp=gsub(' ','',as.matrix(read.delim(scn[i])))
# 			id=scn[i]
# 		}
# 		q=1:nrow(tmp)
# 		if(length(roi)>0){
# 			tmp=tmp[which(tmp[,'chr']==chr),]
# 			q=unique(unlist(lapply(c('start','end'),function(x) intersect(which(as.numeric(tmp[,x])>=as.numeric(roi[2])),which(as.numeric(tmp[,x])<=as.numeric(roi[3]))))))
# 		}
# 		if(length(q)>0){
# 			tmp=tmp[q,]
# 			if(length(q)==1){
# 				tmp=rbind(t(as.matrix(tmp)),rep(0,length(tmp)))
# 				tmp[2,1:3]=rep('nada',3)
# 			}
# 			rownames(tmp)=apply(tmp[,c('chr','start','end')],1,function(x) paste(x,collapse=' '))
# 			tmp2=rownames(tmp)[grep('nada',rownames(tmp),invert=TRUE)]

# 			dd=setdiff(tmp2,rownames(sj))
# 			xx=intersect(tmp2,rownames(sj))
# 			if(length(xx)>0){
# 				sj[xx,'PSI']=as.numeric(sj[xx,'PSI'])+as.numeric(tmp[xx,'PSI'])
# 				sj[xx,'uniq.reads']=as.numeric(sj[xx,'uniq.reads'])+as.numeric(tmp[xx,'uniq.reads'])
# 				sj.samples[xx,'sample.ids']=paste0(sj.samples[xx,'sample.ids'],',',id)
# 				sj.samples[xx,'uniq.reads']=paste0(sj.samples[xx,'uniq.reads'],',',tmp[xx,'uniq.reads'])
# 				sj.samples[xx,'PSI']=paste0(sj.samples[xx,'PSI'],',',tmp[xx,'PSI'])
# 			}
# 			if(length(dd)>0){
# 				tmp.rownames=c(rownames(sj),dd)
# 				sj=rbind(sj,tmp[dd,colnames(sj)])
# 				rownames(sj)=tmp.rownames
# 				if(length(dd)>1) sj.samples=rbind(sj.samples,cbind(id,sj[dd,'uniq.reads'],sj[dd,'PSI']))
# 				if(length(dd)==1) sj.samples=rbind(sj.samples,c(id,sj[dd,'uniq.reads'],sj[dd,'PSI']))
# 			}
# 			n=max(unlist(lapply(c('covPSI','FrameStatus'),function(x) grep(x,colnames(tmp)))))
# 			if((ncol(tmp)-n)>0){
# 				tmp2=setdiff(unique(unlist(strsplit(tmp[,(n+1):ncol(tmp)],'\\|'))),'')
# 				h=NULL
# 				if(length(muts)>0) h=which(is.element(muts[,1],tmp2))
# 				if(length(h)>0){
# 					muts[h,2]=paste(muts[h,2],id,sep=',')
# 					muts[h,3]=as.numeric(muts[h,3])+1
# 				}
# 				xx=tmp2
# 				if(length(muts)>0) xx=setdiff(setdiff(tmp2,muts[,1]),c(NA,''))
# 				if(length(xx)>1) muts=rbind(muts,cbind(xx,id,1))
# 				if(length(xx)==1) muts=rbind(muts,c(xx,id,1))
# 			}
# 		}
# 	}
# 	sj[,'PSI']=as.numeric(sj[,'PSI'])/N
# 	sj[,'uniq.reads']=as.numeric(sj[,'uniq.reads'])/N
# 	if(length(grep('covPSI',colnames(sj)))>0) sj[,'covPSI']=as.numeric(sj[,'covPSI'])/N

# 	if(length(muts)>0) colnames(muts)=c('variant','samples_with_variant','num.samples')

# 	sj[,'uniq.reads']=ceiling(as.numeric(sj[,'uniq.reads']))

# 	out=NULL
# 	if(length(roi0)==3) out$roi=roi
# 	if(length(roi0)==1) out$roi=c(roi,roi0)
# 	if(length(roi0)==0) out$roi='all SJs'
# 	out$sj=sj[grep('nada',rownames(sj),invert=TRUE),]
# 	out$sj.samples=gsub(' ','',sj.samples)
# 	if(length(muts)>0){
# 		out$muts=muts[grep('nada',muts[,1],invert=TRUE),]
# 		if(class(out$muts)!='matrix') out$muts=t(as.matrix(out$muts))
# 	}

# 	return(out)
# }


